<?php 

/**
 * SharedController Controller
 * @category  Controller / Model
 */
class SharedController extends BaseController{
	
	/**
     * trainers2_Sessions_option_list Model Action
     * @return array
     */
	function trainers2_Sessions_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT id AS value,drill_name AS label FROM drills ORDER BY id ASC";
		$arr = $db->rawQuery($sqltext);
		return $arr;
	}

	/**
     * quotescontent_list Model Action
     * @return array
     */
	function quotescontent_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT content , content ,   COUNT(*) AS num FROM quotes GROUP BY content ORDER BY Author ASC";
		$arr = $db->rawQuery($sqltext);
		return $arr;
	}

	/**
     * alertscontent_list Model Action
     * @return array
     */
	function alertscontent_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT content , content ,   COUNT(*) AS num FROM alerts GROUP BY content ORDER BY Title ASC";
		$arr = $db->rawQuery($sqltext);
		return $arr;
	}

	/**
     * getcount_drills Model Action
     * @return Value
     */
	function getcount_drills(){
		$db = $this->GetModel();
		$sqltext = "SELECT COUNT(*) AS num FROM drills";
		$arr = $db->rawQueryValue($sqltext);
		return $arr[0];
	}

	/**
     * getcount_users Model Action
     * @return Value
     */
	function getcount_users(){
		$db = $this->GetModel();
		$sqltext = "SELECT COUNT(*) AS num FROM users";
		$arr = $db->rawQueryValue($sqltext);
		return $arr[0];
	}

	/**
     * getcount_ourtrainers Model Action
     * @return Value
     */
	function getcount_ourtrainers(){
		$db = $this->GetModel();
		$sqltext = "SELECT COUNT(*) AS num FROM trainers2";
		$arr = $db->rawQueryValue($sqltext);
		return $arr[0];
	}

	/**
     * getcount_quotes Model Action
     * @return Value
     */
	function getcount_quotes(){
		$db = $this->GetModel();
		$sqltext = "SELECT COUNT(*) AS num FROM quotes";
		$arr = $db->rawQueryValue($sqltext);
		return $arr[0];
	}

	/**
	* radarchart_recruitmentreport Model Action
	* @return array
	*/
	function radarchart_recruitmentreport(){
		
		$db = $this->GetModel();
		$arr = array();
		
		$dataset1 = $db->rawQuery("SELECT  t.id, t.name, t.experience, t.gym_no, t.Sessions, t.preffered_gender_group, t.description FROM trainers2 AS t GROUP BY t.id, t.name, t.experience, t.gym_no, t.Sessions, t.preffered_gender_group, t.description");
		$dataset2 = $db->rawQuery("SELECT  u.id, u.name, u.gender FROM users AS u");
		$arr['labels']=array_map(function($var){ return $var['id']; }, $dataset1);
		
		$arr['datasets'][] = array_map(function($var){ return $var['name']; }, $dataset1);
		$arr['datasets'][] = array_map(function($var){ return $var['name']; }, $dataset2);
		return $arr;
	}

	/**
     * getcount_alerts Model Action
     * @return Value
     */
	function getcount_alerts(){
		$db = $this->GetModel();
		$sqltext = "SELECT COUNT(*) AS num FROM alerts";
		$arr = $db->rawQueryValue($sqltext);
		return $arr[0];
	}

	/**
	* doughnutchart_drills_report Model Action
	* @return array
	*/
	function doughnutchart_drills_report(){
		
		$db = $this->GetModel();
		$arr = array();
		
		$dataset1 = $db->rawQuery("SELECT  a.id, a.Title, a.headline, a.content FROM alerts AS a");
		$dataset2 = $db->rawQuery("SELECT  t.id, t.name, t.experience, t.gym_no, t.Sessions, t.preffered_gender_group, t.description FROM trainers2 AS t");
		$arr['labels']=array_map(function($var){ return $var['id']; }, $dataset1);
		
		$arr['datasets'][] = array_map(function($var){ return $var['Title']; }, $dataset1);
		$arr['datasets'][] = array_map(function($var){ return $var['Title']; }, $dataset2);
		return $arr;
	}

	/**
     * getcount_booktrainer Model Action
     * @return Value
     */
	function getcount_booktrainer(){
		$db = $this->GetModel();
		$sqltext = "SELECT COUNT(*) AS num FROM book_trainer";
		$arr = $db->rawQueryValue($sqltext);
		return $arr[0];
	}

}
