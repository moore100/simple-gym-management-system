<div class="container">
	<div class="card card-body">
		<div class="row">
			<div class="col  text-center">
				<i class="material-icons mi-xlg text-danger">block</i>
			</div>
			<div class="col-10">
				<h3 class="text-danger">Unknown user role</h3>
				<div class="text-muted"><i>Please meet the system administrator for more information!</i></div>
				<hr />
				<div class="">
					<a href="<?php print_link(HOME_PAGE); ?>" class="btn btn-primary">Go to home page</a>
				</div>
			</div>
		</div>
	</div>
</div>