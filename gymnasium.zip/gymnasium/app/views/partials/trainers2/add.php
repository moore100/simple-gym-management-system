
<?php
$comp_model = new SharedController;

$show_header = $this->show_header;
$view_title = $this->view_title;
$redirect_to = $this->redirect_to;

?>

<section class="page">
    
    <?php
    if( $show_header == true ){
    ?>
    
    <div  class="bg-light p-3 mb-3">
        <div class="container">
            
            <div class="row ">
                
                <div class="col-12 comp-grid">
                    <h3 class="record-title">Add New Trainers2</h3>
                    
                </div>
                
            </div>
        </div>
    </div>
    
    <?php
    }
    ?>
    
    <div  class="">
        <div class="container">
            
            <div class="row ">
                
                <div class="col-md-7 comp-grid">
                    
                    <?php $this :: display_page_errors(); ?>
                    
                    <div  class="card animated fadeIn">
                        <form id="trainers2-add-form" role="form" enctype="multipart/form-data" class="form form-horizontal needs-validation"  novalidate action="<?php print_link("trainers2/add") ?>" method="post">
                            <div class="card-body">
                                
                                
                                <div class="form-group ">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <label class="control-label" for="name">Name <span class="text-danger">*</span></label>
                                        </div>
                                        <div class="col-sm-8">
                                            <div class="">
                                                <input  id="name" value="<?php  echo $this->set_field_value('name',''); ?>" type="text" placeholder="Enter Name"  required="" name="name" class="form-control " />
                                                    
                                                    
                                                    
                                                </div>
                                                
                                                
                                            </div>
                                        </div>
                                    </div>
                                    
                                    
                                    
                                    
                                    <div class="form-group ">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <label class="control-label" for="experience">Experience <span class="text-danger">*</span></label>
                                            </div>
                                            <div class="col-sm-8">
                                                <div class="">
                                                    <input  id="experience" value="<?php  echo $this->set_field_value('experience',''); ?>" type="text" placeholder="Enter Experience"  required="" name="experience" class="form-control " />
                                                        
                                                        
                                                        
                                                    </div>
                                                    
                                                    
                                                </div>
                                            </div>
                                        </div>
                                        
                                        
                                        
                                        
                                        <div class="form-group ">
                                            <div class="row">
                                                <div class="col-sm-4">
                                                    <label class="control-label" for="gym_no">Gym No <span class="text-danger">*</span></label>
                                                </div>
                                                <div class="col-sm-8">
                                                    <div class="">
                                                        <input  id="gym_no" value="<?php  echo $this->set_field_value('gym_no',''); ?>" type="text" placeholder="Enter Gym No"  required="" name="gym_no" class="form-control " />
                                                            
                                                            
                                                            
                                                        </div>
                                                        
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            
                                            
                                            
                                            <div class="form-group ">
                                                <div class="row">
                                                    <div class="col-sm-4">
                                                        <label class="control-label" for="Sessions">Sessions <span class="text-danger">*</span></label>
                                                    </div>
                                                    <div class="col-sm-8">
                                                        <div class="">
                                                            <select required=""  name="Sessions" placeholder="Select a value ..."    class="form-control">
                                                                <option value="">Select a value ...</option>
                                                                
                                                                <?php 
                                                                $Sessions_options = $comp_model -> trainers2_Sessions_option_list();
                                                                
                                                                if(!empty($Sessions_options)){
                                                                foreach($Sessions_options as $arr){
                                                                $val=array_values($arr);
                                                                ?>
                                                                <option <?php echo $this->set_field_selected('Sessions',$val[0]) ?> value="<?php echo $val[0]; ?>">
                                                                    <?php echo (!empty($val[1]) ? $val[1] : $val[0]); ?>
                                                                </option>
                                                                <?php
                                                                }
                                                                }
                                                                ?>
                                                                
                                                            </select> 
                                                            
                                                        </div>
                                                        
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            
                                            
                                            
                                            <div class="form-group ">
                                                <div class="row">
                                                    <div class="col-sm-4">
                                                        <label class="control-label" for="preffered_gender_group">Preffered Gender Group <span class="text-danger">*</span></label>
                                                    </div>
                                                    <div class="col-sm-8">
                                                        <div class="">
                                                            
                                                            <label class="">
                                                                <input <?php echo $this->set_field_checked('preffered_gender_group','Male'); ?> value="Male" type="radio" required=""  name="preffered_gender_group" />
                                                                    Male
                                                                </label>
                                                                <label class="">
                                                                    <input <?php echo $this->set_field_checked('preffered_gender_group','Female'); ?> value="Female" type="radio" required=""  name="preffered_gender_group" />
                                                                        Female
                                                                    </label> 
                                                                    
                                                                </div>
                                                                
                                                                
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    
                                                    
                                                    
                                                    <div class="form-group ">
                                                        <div class="row">
                                                            <div class="col-sm-4">
                                                                <label class="control-label" for="description">Description <span class="text-danger">*</span></label>
                                                            </div>
                                                            <div class="col-sm-8">
                                                                <div class="">
                                                                    <textarea placeholder="Enter Description" required="" rows="" name="description" class=" form-control"><?php  echo $this->set_field_value('description',''); ?></textarea>
                                                                    
                                                                    
                                                                </div>
                                                                
                                                                
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    
                                                    
                                                    
                                                </div>
                                                <div class="form-group form-submit-btn-holder text-center">
                                                    <button class="btn btn-primary" type="submit">
                                                        
                                                        <i class="fa fa-send"></i>
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                        
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        
                    </section>
                    