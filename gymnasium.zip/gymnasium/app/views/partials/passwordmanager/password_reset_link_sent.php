<div class="container">
	<h3>Password Reset </h3>
	<hr />
	<div class="card card-body">
		<h4 class="text-success bold">
			<i class="fa fa-envelope"></i> A message has been sent to your email. Kindly follow the link to reset your password 
		</h4>
	</div>
</div>