<div class="container">
	<div>
		<h3>Password Reset </h3>
	</div>
	<hr />	
	<div class="alert alert-success animated bounce">
		vradicon[check_box]vradicon Your password has been reset
	</div>
	<hr />
	<a href="<?php print_link("index/login"); ?>" class="btn btn-info">Click here to login</a>
</div>
	