
		<?php 
			$comp_model = new SharedController;
		?>
		<div>
			
		<div  class="border-top">
			<div class="container-fluid">
				
			<div class="page-header"><h3>MKU GYM MANAGEMENT SYSTEM</h3></div>

				<div class="row justify-content-end">
					
		<div class="col-md-5 comp-grid">
			
		
		<button data-toggle="modal" data-target="#Btn-Modal-1"  class="btn btn-primary">
			<i class="fa fa-user-plus "></i>									
			Add a user 
		</button>
		
		<div data-backdrop="true" id="Btn-Modal-1" class="modal fade"  role="dialog" aria-labelledby="Btn-Modal-1" aria-hidden="true">
			<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
				<div class="modal-content">
					<div class="modal-body reset-grids">
						
	<div class=" ">
		<?php  
			
			$this->render_page("users/add"); 
		?>
	</div>

					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				</div>
			</div>
		</div>

					<a  class="btn btn-primary" href="<?php print_link("home") ?>">
						<i class="fa fa-refresh "></i>								
						refresh page 
					</a>

		</div>

				</div>
			</div>
		</div>

		<div  class="">
			<div class="container">
				
				<div class="row ">
					
		<div class="col-md-12 comp-grid">
			<div class="card ">
		<div class="card-header p-0 pt-2 px-2">
	<ul class="nav  nav-tabs   ">
		
					<li class="nav-item">
						<a class="nav-link active" data-toggle="tab" href="#TabPage-1-Page1" role="tab" aria-selected="true">
							<i class="fa fa-quote-left "></i> Quotes
						</a>
					</li>

					<li class="nav-item">
						<a class="nav-link " data-toggle="tab" href="#TabPage-1-Page2" role="tab" aria-selected="true">
							Alerts Alerts
						</a>
					</li>

	</ul>
</div>
		<div class="card-body">
	<div class="tab-content">
		
					<div class="tab-pane show active fade" id="TabPage-1-Page1" role="tabpanel">
						
				<div class=" position-relative mb-2">
					
					<div  class="card mb-3" >
						quotes
						<?php 
							$arr_menu = array();
							$menus = $comp_model->quotescontent_list(); // Get menu items from database
							if(!empty($menus)){
								//build menu items into arrays
								foreach($menus as $menu){
									$arr_menu[] = array(
										"path"=>"quotes/list/content/$menu[content]", 
										"label"=>"$menu[content] <span class='badge badge-primary float-right'>$menu[num]</span>", 
										"icon"=>'<i class="fa fa-quote-right "></i>'
									);
								}
								//call menu render helper.
								Html :: render_menu($arr_menu , "nav nav-tabs flex-column");
							}
						?>
					</div>
				</div>
				
					</div>

					<div class="tab-pane  fade" id="TabPage-1-Page2" role="tabpanel">
						
				<div class=" position-relative mb-2">
					
					<div  class="card mb-3" >
						Alerts
						<?php 
							$arr_menu = array();
							$menus = $comp_model->alertscontent_list(); // Get menu items from database
							if(!empty($menus)){
								//build menu items into arrays
								foreach($menus as $menu){
									$arr_menu[] = array(
										"path"=>"alerts/list/content/$menu[content]", 
										"label"=>"$menu[content] <span class='badge badge-primary float-right'>$menu[num]</span>", 
										"icon"=>'<i class="fa fa-bell-o "></i>'
									);
								}
								//call menu render helper.
								Html :: render_menu($arr_menu , "nav nav-tabs flex-column");
							}
						?>
					</div>
				</div>
				
					</div>

	</div>
</div>
</div>
		</div>

				</div>
			</div>
		</div>

		<div  class="">
			<div class="container">
				
				<div class="row ">
					
		<div class="col-md-12 comp-grid">
			
					<?php $rec_count = $comp_model->getcount_drills();  ?>
					<a class="animated swing record-count card bg-success text-white"  href="<?php print_link("drills/") ?>">
						<div class="row">
							<div class="col-2">
								<i class="fa fa-angle-double-up "></i>
							</div>
							<div class="col-10">
								<div class="flex-column justify-content align-center">
									<div class="title">Drills</div>
									
									<small class="">add &manage Drills</small>
								</div>
							</div>
							<h4 class="value"><strong><?php echo $rec_count; ?></strong></h4>
						</div>
						
					</a>
			
		</div>

		<div class="col-md-4 comp-grid">
			
					<?php $rec_count = $comp_model->getcount_users();  ?>
					<a class="animated swing record-count card bg-success text-white"  href="<?php print_link("users/") ?>">
						<div class="row">
							<div class="col-2">
								<i class="fa fa-users "></i>
							</div>
							<div class="col-10">
								<div class="flex-column justify-content align-center">
									<div class="title">Users</div>
									
									<small class="">add &manage users</small>
								</div>
							</div>
							<h4 class="value"><strong><?php echo $rec_count; ?></strong></h4>
						</div>
						
					</a>
			
					<?php $rec_count = $comp_model->getcount_ourtrainers();  ?>
					<a class="animated record-count alert alert-primary"  href="<?php print_link("trainers2/") ?>">
						<div class="row">
							<div class="col-2">
								<i class="fa fa-user-plus "></i>
							</div>
							<div class="col-10">
								<div class="flex-column justify-content align-center">
									<div class="title">Our Trainers</div>
									
				<div class="progress mt-2">
					<?php 
						$perc = ($rec_count / 100) * 100 ;
					?>
					<div class="progress-bar bg-success" role="progressbar" aria-valuenow="<?php echo $rec_count; ?>" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $perc ?>%">
						<span class="progress-label"><?php echo round($perc,2); ?>%</span>
					</div>
				</div>
		
									<small class="small desc">Add & Manage Trainers here (recruitment ongoing)</small>
								</div>
							</div>
							<h4 class="value"><strong><?php echo $rec_count; ?></strong></h4>
						</div>
					</a>
			
	<div class="card reset-grids">
		<?php  
			
			$this->render_page("alerts/add"); 
		?>
	</div>

		</div>

		<div class="col-md-4 comp-grid">
			
					<?php $rec_count = $comp_model->getcount_quotes();  ?>
					<a class="animated swing record-count card bg-secondary text-white"  href="<?php print_link("quotes/") ?>">
						<div class="row">
							<div class="col-2">
								<i class="fa fa-quote-left "></i>
							</div>
							<div class="col-10">
								<div class="flex-column justify-content align-center">
									<div class="title">Quotes</div>
									
									<small class="">add &manage Quotes</small>
								</div>
							</div>
							<h4 class="value"><strong><?php echo $rec_count; ?></strong></h4>
						</div>
						
					</a>
			
		
		<button data-toggle="modal" data-target="#Btn-Modal-2"  class="btn btn-primary">
			<i class="fa fa-quote-right "></i>									
			Add quote 
		</button>
		
		<div data-backdrop="true" id="Btn-Modal-2" class="modal fade"  role="dialog" aria-labelledby="Btn-Modal-2" aria-hidden="true">
			<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
				<div class="modal-content">
					<div class="modal-body reset-grids">
						
	<div class=" ">
		<?php  
			
			$this->render_page("quotes/add"); 
		?>
	</div>

					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				</div>
			</div>
		</div>

	
	<button data-toggle="modal" data-target="#Modal-3-Page1" class="btn btn-primary"><i class='fa fa-plus-square-o '></i>  add a drill</button>
	<div data-backdrop="true" class="modal fade" id="Modal-3-Page1" tabindex="-1" role="dialog" aria-labelledby="Modal1" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
			<div class="modal-content">
				
	<div class="modal-header">
		<h5 class="modal-title" id="exampleModalLongTitle"><i class='fa fa-plus-square-o '></i>  Modal Contents</h5>
		<button type="button" class="close" data-dismiss="modal" aria-label="Close">
			<span aria-hidden="true">&times;</span>
		</button>
	</div>

				<div class="modal-body reset-grids">
					
	<div class="card reset-grids">
		<?php  
			
			$this->render_page("drills/add"); 
		?>
	</div>

				</div>
				
			</div>
		</div>
	</div>


	<div class="card card-body">
		<?php 
			$chartdata = $comp_model->radarchart_recruitmentreport();
		?>
		<div>
			<h4>Recruitment report</h4>
			<small class="text-muted">reports for the recruitment go here</small>
		</div>
		<hr />
		<canvas id="radarchart_recruitmentreport"></canvas>
		<script>
			$(function (){
			var chartData = {
				labels : <?php echo json_encode($chartdata['labels']); ?>,
				datasets : [
					{
					label: 'trainees',
					
					backgroundColor:[
								<?php 
									foreach($chartdata['labels'] as $g){
										echo "'" . random_color(0.9) . "',";
									}
								?>
							],
					
					borderWidth:3,
					pointStyle:'circle',
					pointRadius:5,
					lineTension:0.1,
					type:'',
					steppedLine:false,
					data : <?php echo json_encode($chartdata['datasets'][0]); ?>,
				},{
					label: 'Trainers',
					
					backgroundColor:[
								<?php 
									foreach($chartdata['labels'] as $g){
										echo "'" . random_color(0.9) . "',";
									}
								?>
							],
					
					borderWidth:3,
					pointStyle:'circle',
					pointRadius:5,
					lineTension:0.1,
					type:'',
					steppedLine:false,
					data : <?php echo json_encode($chartdata['datasets'][1]); ?>,
				}
				]
			}
			var ctx = document.getElementById('radarchart_recruitmentreport');
			var chart = new Chart(ctx, {
				type:'radar',
				data: chartData,
				
	options: {
		responsive: true,
		scales: {
			yAxes: [{
				ticks:{display: false},
				gridLines:{display: false},
				scaleLabel: {
					display: true,
					labelString: "new_trainees"
				}
			}],
			xAxes: [{
				ticks:{display: false},
				gridLines:{display: false},
				scaleLabel: {
					display: true,
					labelString: "new_trainers"
				}
			}],
		},
	}
,
			})});
		</script>
	</div>

		</div>

		<div class="col-md-4 comp-grid">
			
					<?php $rec_count = $comp_model->getcount_alerts();  ?>
					<a class="animated zoomIn record-count card bg-danger text-white"  href="<?php print_link("alerts/") ?>">
						<div class="row">
							<div class="col-2">
								<i class="fa fa-bell "></i>
							</div>
							<div class="col-10">
								<div class="flex-column justify-content align-center">
									<div class="title">Alerts</div>
									
									<small class="">add &manage Alerts</small>
								</div>
							</div>
							<h4 class="value"><strong><?php echo $rec_count; ?></strong></h4>
						</div>
						
					</a>
			
	<div class="card card-body">
		<?php 
			$chartdata = $comp_model->doughnutchart_drills_report();
		?>
		<div>
			<h4>Drills_report</h4>
			<small class="text-muted">sessions_report</small>
		</div>
		<hr />
		<canvas id="doughnutchart_drills_report"></canvas>
		<script>
			$(function (){
			var chartData = {
				labels : <?php echo json_encode($chartdata['labels']); ?>,
				datasets : [
					{
					label: 'Dataset 1',
					
					backgroundColor:'<?php echo random_color(0.9); ?>',
					borderWidth:3,
					data : <?php echo json_encode($chartdata['datasets'][0]); ?>,
				},{
					label: 'Dataset 2',
					
					backgroundColor:'<?php echo random_color(0.9); ?>',
					borderWidth:3,
					data : <?php echo json_encode($chartdata['datasets'][1]); ?>,
				}
				]
			}
			var ctx = document.getElementById('doughnutchart_drills_report');
			var chart = new Chart(ctx, {
				type:'doughnut',
				data: chartData,
				
	options: {
		responsive: true,
		scales: {
			yAxes: [{
				ticks:{display: false},
				gridLines:{display: false},
				scaleLabel: {
					display: true,
					labelString: "drills"
				}
			}],
			xAxes: [{
				ticks:{display: false},
				gridLines:{display: false},
				scaleLabel: {
					display: true,
					labelString: "sessioins"
				}
			}],
		},
	}
,
			})});
		</script>
	</div>

		</div>

				</div>
			</div>
		</div>

		<div  class="">
			<div class="container">
				
				<div class="row ">
					
		<div class="col-md-4 comp-grid">
			
		</div>

		<div class="col-md-4 comp-grid">
			
		</div>

				</div>
			</div>
		</div>

		<div  class="">
			<div class="container">
				
				<div class="row ">
					
		<div class="col-md-12 comp-grid">
			
		</div>

				</div>
			</div>
		</div>

		</div>
	