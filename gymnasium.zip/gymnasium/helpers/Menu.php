<?php
/**
 * Menu Items
 * All Project Menu
 * @category  Menu List
 */

class Menu{
	
	
	public static $navbartopleft = array(
		array(
			'path' => '/', 
			'label' => 'home', 
			'icon' => '<i class="fa fa-home "></i>','submenu' => array(
		array(
			'path' => '//Index', 
			'label' => 'home', 
			'icon' => '<i class="fa fa-home "></i>'
		),
		
		array(
			'path' => 'drills/list', 
			'label' => 'Drills', 
			'icon' => '<i class="fa fa-asterisk "></i>'
		)
	)
		),
		
		array(
			'path' => 'home', 
			'label' => 'Users', 
			'icon' => '<i class="fa fa-users "></i>','submenu' => array(
		array(
			'path' => 'users/Index', 
			'label' => 'Users', 
			'icon' => ''
		),
		
		array(
			'path' => 'trainers2/list', 
			'label' => 'Our Trainers', 
			'icon' => '<i class="fa fa-user-plus "></i>'
		)
	)
		)
	);

	
	
}